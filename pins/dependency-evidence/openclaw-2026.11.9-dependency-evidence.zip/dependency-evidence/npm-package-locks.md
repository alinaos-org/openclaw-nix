# npm package-lock mirrors

Source: `0032b1d7ffd0a59afdf7d2223d8df3250df9057e` (OpenClaw 2026.11.9).
pnpm lock SHA-256: `0c520acce014745ab0815ce25c6dd890ed30456eb326dfe961f317a73649c87f`.

Total packages: 52
Total bundled dependencies: 147
Lockless packages (bundleRuntimeDependencies=false): 10
Partial locks (omitted workspace dependencies): 2

Entries with non-empty omittedWorkspaceDependencies are partial locks: sibling workspace packages publish in the same release and are omitted by the generator. Consumers must reject these entries instead of installing them.
Select the exact name and version in npm-package-locks.json, require an empty omittedWorkspaceDependencies array, and write entry.lock as package-lock.json.
Verify dependency-evidence-manifest.json releaseSha equals sourceSha and the OpenClaw commit you pin.
These generated locks are release evidence only and are never included in npm tarballs.

| Package directory | Name | Version | Bundles runtime dependencies | Dependencies | Optional dependencies | Omitted workspace dependencies | Bundled dependencies |
| --- | --- | --- | --- | --- | --- | --- | --- |
| . | openclaw | 2026.11.9 | false | 77 | 1 | Partial: @openclaw/ai | 147 |
| extensions/acpx | @openclaw/acpx | 2026.11.9 | false | 6 | 0 | None | 0 |
| extensions/amazon-bedrock | @openclaw/amazon-bedrock-provider | 2026.11.9 | true | 5 | 0 | None | 0 |
| extensions/amazon-bedrock-mantle | @openclaw/amazon-bedrock-mantle-provider | 2026.11.9 | true | 2 | 0 | None | 0 |
| extensions/anthropic-vertex | @openclaw/anthropic-vertex-provider | 2026.11.9 | true | 3 | 0 | None | 0 |
| extensions/buzz | @openclaw/buzz | 2026.11.9 | true | 2 | 0 | None | 0 |
| extensions/clickclack | @openclaw/clickclack | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/cloudflare | @openclaw/cloudflare | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/codex | @openclaw/codex | 2026.11.9 | false | 8 | 0 | None | 0 |
| extensions/copilot | @openclaw/copilot | 2026.11.9 | false | 1 | 0 | None | 0 |
| extensions/diagnostics-otel | @openclaw/diagnostics-otel | 2026.11.9 | true | 14 | 0 | None | 0 |
| extensions/diffs | @openclaw/diffs | 2026.11.9 | true | 5 | 0 | None | 0 |
| extensions/discord | @openclaw/discord | 2026.11.9 | true | 9 | 0 | None | 0 |
| extensions/facetime | @openclaw/facetime | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/feishu | @openclaw/feishu | 2026.11.9 | true | 6 | 0 | None | 0 |
| extensions/firecrawl | @openclaw/firecrawl-plugin | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/google-meet | @openclaw/google-meet | 2026.11.9 | true | 2 | 0 | None | 0 |
| extensions/googlechat | @openclaw/googlechat | 2026.11.9 | true | 2 | 0 | None | 0 |
| extensions/imessage | @openclaw/imessage | 2026.11.9 | true | 2 | 0 | None | 0 |
| extensions/irc | @openclaw/irc | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/line | @openclaw/line | 2026.11.9 | true | 3 | 0 | None | 0 |
| extensions/llama-cpp | @openclaw/llama-cpp-provider | 2026.11.9 | false | 1 | 0 | None | 0 |
| extensions/lobster | @openclaw/lobster | 2026.11.9 | true | 2 | 0 | None | 0 |
| extensions/matrix | @openclaw/matrix | 2026.11.9 | true | 9 | 0 | None | 0 |
| extensions/mattermost | @openclaw/mattermost | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/memory-lancedb | @openclaw/memory-lancedb | 2026.11.9 | true | 3 | 7 | None | 0 |
| extensions/memory-wiki | @openclaw/memory-wiki | 2026.11.9 | true | 4 | 0 | None | 0 |
| extensions/msteams | @openclaw/msteams | 2026.11.9 | false | 6 | 0 | None | 0 |
| extensions/muse | @openclaw/muse | 2026.11.9 | false | 1 | 0 | None | 0 |
| extensions/mxc | @openclaw/mxc-sandbox | 2026.11.9 | true | 2 | 0 | None | 0 |
| extensions/nextcloud-talk | @openclaw/nextcloud-talk | 2026.11.9 | true | 2 | 0 | None | 0 |
| extensions/nostr | @openclaw/nostr | 2026.11.9 | true | 4 | 0 | None | 0 |
| extensions/onnx | @openclaw/onnx | 2026.11.9 | false | 2 | 1 | None | 0 |
| extensions/openshell | @openclaw/openshell-sandbox | 2026.11.9 | true | 3 | 0 | None | 0 |
| extensions/raft | @openclaw/raft | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/signal | @openclaw/signal | 2026.11.9 | true | 2 | 0 | None | 0 |
| extensions/slack | @openclaw/slack | 2026.11.9 | true | 7 | 0 | None | 0 |
| extensions/sms | @openclaw/sms | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/synology-chat | @openclaw/synology-chat | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/tavily | @openclaw/tavily-plugin | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/team-reports | @openclaw/team-reports | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/tlon | @openclaw/tlon | 2026.11.9 | false | 5 | 0 | None | 0 |
| extensions/tokenjuice | @openclaw/tokenjuice | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/twitch | @openclaw/twitch | 2026.11.9 | false | 4 | 0 | None | 0 |
| extensions/typesafe | @openclaw/typesafe | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/voice-call | @openclaw/voice-call | 2026.11.9 | true | 2 | 0 | None | 0 |
| extensions/whatsapp | @openclaw/whatsapp | 2026.11.9 | true | 5 | 0 | None | 0 |
| extensions/zalo | @openclaw/zalo | 2026.11.9 | true | 1 | 0 | None | 0 |
| extensions/zalouser | @openclaw/zalouser | 2026.11.9 | true | 3 | 0 | None | 0 |
| packages/ai | @openclaw/ai | 2026.11.9 | true | 9 | 0 | None | 0 |
| packages/gateway-client | @openclaw/gateway-client | 2026.11.9 | true | 4 | 0 | Partial: @openclaw/gateway-protocol | 0 |
| packages/gateway-protocol | @openclaw/gateway-protocol | 2026.11.9 | true | 1 | 0 | None | 0 |
